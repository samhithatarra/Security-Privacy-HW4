#include <stdio.h>
#include <string.h>


greeting( int v1 )
{
	char name[400];
}


int main(int argc, char* argv[] ) 
{
	int p1;
	greeting( p1 );
}
